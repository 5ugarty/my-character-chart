"use client"

import { MemberCard } from "@/components/member-card"

const members = [
  {
    name: "Bang Chan",
    nameKo: "방찬",
    imageUrl: "/members/bangchan.jpg",
    defaultValue: 70,
  },
  {
    name: "Lee Know",
    nameKo: "리노",
    imageUrl: "/members/leeknow.jpg",
    defaultValue: 60,
  },
  {
    name: "Changbin",
    nameKo: "창빈",
    imageUrl: "/members/changbin.jpg",
    defaultValue: 75,
  },
  {
    name: "Hyunjin",
    nameKo: "현진",
    imageUrl: "/members/hyunjin.jpg",
    defaultValue: 40,
  },
  {
    name: "Han",
    nameKo: "한",
    imageUrl: "/members/han.jpg",
    defaultValue: 55,
  },
  {
    name: "Felix",
    nameKo: "필릭스",
    imageUrl: "/members/felix.jpg",
    defaultValue: 35,
  },
  {
    name: "Seungmin",
    nameKo: "승민",
    imageUrl: "/members/seungmin.jpg",
    defaultValue: 65,
  },
  {
    name: "I.N",
    nameKo: "아이엔",
    imageUrl: "/members/in.jpg",
    defaultValue: 30,
  },
]

export function CharacterChart() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:py-12">
      <header className="mb-8 md:mb-10">
        <h1 className="text-3xl font-black tracking-tight text-foreground md:text-4xl text-balance">
          Stray Kids 공수 취향표
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          슬라이더를 움직여 공/수 비율을 조절하고, 각 멤버에 대한 분석을 입력하세요.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {members.map((m) => (
            <span
              key={m.name}
              className="rounded-md border border-border bg-muted/50 px-2.5 py-1 text-xs font-semibold text-foreground"
            >
              {m.nameKo}
            </span>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:gap-5">
        {members.map((member) => (
          <MemberCard
            key={member.name}
            name={member.name}
            nameKo={member.nameKo}
            imageUrl={member.imageUrl}
            defaultValue={member.defaultValue}
          />
        ))}
      </div>

      <footer className="mt-8 text-center text-xs text-muted-foreground">
        Stray Kids 공수 취향표 &middot; 이미지를 교체하려면 public/members 폴더에 파일을 넣어주세요
      </footer>
    </div>
  )
}
